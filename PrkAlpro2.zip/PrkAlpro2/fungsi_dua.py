def hitung_fungsi(x):
    hasil = 2*x**2 + 2*x
    return hasil

x = int(input("Nilai x (Bilangan Bulat): "))
hasil_fungsi = hitung_fungsi(x)
print("Hasil fungsi f(x):", hasil_fungsi)